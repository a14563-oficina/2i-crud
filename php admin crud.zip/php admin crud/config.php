<?php

$conn = mysqli_connect('sql112.alojamento-gratis.com','ljmn_38553748','tqzadtqzad','ljmn_38553748_cart_db');

?>